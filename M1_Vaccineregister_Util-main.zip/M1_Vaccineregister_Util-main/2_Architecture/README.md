#*ARCHITECTURE*

    ##FLOWCHART

![Flowchart1](https://user-images.githubusercontent.com/98849090/153299744-8d5bb0de-0ef3-43fb-b428-b71ef28f84a3.jpg) 



#*UML DIAGRAM*

![UML Use code](https://user-images.githubusercontent.com/98849090/153289642-4e3543af-ada5-408a-838b-345f46fbcb3c.jpg)

