#include <stdio.h>
int main()
{
    printf("Welcome to Github Actions\n");
    printf("\n*******Hurry, It works******\n");
    return 0;
}
